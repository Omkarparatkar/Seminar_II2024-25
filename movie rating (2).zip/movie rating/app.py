from flask import Flask, request, jsonify, send_from_directory, send_file
from werkzeug.utils import secure_filename
from flask_cors import CORS
from database import execute_query, execute_single_query
import json
import os
import uuid

app = Flask(__name__)
CORS(app)

# Configuration
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

# Ensure upload directory exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_uploaded_file(file):
    """Save uploaded file and return the relative path"""
    if file and allowed_file(file.filename):
        # Generate unique filename to avoid conflicts
        file_extension = file.filename.rsplit('.', 1)[1].lower()
        unique_filename = f"{uuid.uuid4()}.{file_extension}"
        filepath = os.path.join(UPLOAD_FOLDER, unique_filename)
        file.save(filepath)
        return f"./uploads/{unique_filename}"
    return None

# DASHBOARD ENDPOINTS
@app.route('/api/dashboard/stats', methods=['GET'])
def get_dashboard_stats():
    """Get dashboard statistics"""
    stats = {}
    
    # Get total movies
    result = execute_single_query("SELECT COUNT(*) as count FROM movies")
    stats['total_movies'] = result['count'] if result else 0
    
    # Get total users
    result = execute_single_query("SELECT COUNT(*) as count FROM users")
    stats['total_users'] = result['count'] if result else 0
    
    # Get total reviews
    result = execute_single_query("SELECT COUNT(*) as count FROM reviews")
    stats['total_reviews'] = result['count'] if result else 0
    
    # Get average rating
    result = execute_single_query("SELECT AVG(rating) as avg_rating FROM movies WHERE rating > 0")
    stats['avg_rating'] = round(float(result['avg_rating']) if result and result['avg_rating'] else 0, 1)
    
    return jsonify(stats)

@app.route('/api/dashboard/activities', methods=['GET'])
def get_recent_activities():
    """Get recent activities"""
    activities = execute_query("SELECT * FROM activities ORDER BY id DESC LIMIT 10", fetch=True)
    return jsonify(activities or [])

# MOVIE ENDPOINTS
@app.route('/api/movies', methods=['GET'])
def get_movies():
    """Get all movies with optional search"""
    search = request.args.get('search', '').lower()
    
    if search:
        query = """
            SELECT * FROM movies 
            WHERE LOWER(title) LIKE %s OR LOWER(genre) LIKE %s
            ORDER BY id DESC
        """
        movies = execute_query(query, (f'%{search}%', f'%{search}%'), fetch=True)
    else:
        movies = execute_query("SELECT * FROM movies ORDER BY id DESC", fetch=True)
    
    print(movies)
    
    return jsonify(movies or [])

@app.route('/api/movies', methods=['POST'])
def add_movie():
    """Add a new movie with image upload support"""
    try:
        # Handle multipart form data
        data = {}
        
        # Get text fields
        for key in request.form:
            if key != 'cast':
                data[key] = request.form[key]
        
        # Parse cast data
        cast_data = request.form.get('cast', '[]')
        try:
            data['cast'] = json.loads(cast_data)
        except json.JSONDecodeError:
            data['cast'] = []
        
        # Handle file upload
        poster_url = ''
        if 'poster_image' in request.files:
            file = request.files['poster_image']
            if file.filename != '':
                saved_path = save_uploaded_file(file)
                if saved_path:
                    poster_url = saved_path
                else:
                    return jsonify({'error': 'Invalid file type. Please upload PNG, JPG, JPEG, GIF, or WebP images.'}), 400
        
        # Validate required fields
        required_fields = ['title', 'release_year', 'genre']
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({'error': f'{field} is required'}), 400
        
        # Prepare data for database insertion
        query = """
            INSERT INTO movies (title, release_year, genre, duration, director, language, 
                      description, "cast", poster_url, trailer_url, rating, review_count)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING *
        """
        
        cast_json = json.dumps(data.get('cast', []))
        
        params = (
            data['title'],
            int(data['release_year']),
            data['genre'],
            int(data.get('duration', 0)) if data.get('duration') else None,
            data.get('director', ''),
            data.get('language', ''),
            data.get('description', ''),
            cast_json,
            poster_url,  # Use the uploaded file path
            data.get('trailer_url', ''),
            0.0,
            0
        )
        
        new_movie = execute_single_query(query, params)
        
        if new_movie:
            # Add activity
            execute_query("""
                INSERT INTO activities (activity, user_name, movie, date)
                VALUES (%s, %s, %s, %s)
            """, ('Movie Added', 'admin', new_movie['title'], 'Just now'))
            
            return jsonify({'message': 'Movie added successfully', 'movie': new_movie}), 201
        else:
            return jsonify({'error': 'Failed to add movie'}), 500
            
    except Exception as e:
        print(f"Error adding movie: {str(e)}")
        return jsonify({'error': 'An error occurred while adding the movie'}), 500
    
@app.route('/api/movies/<int:movie_id>', methods=['GET'])
def get_movie(movie_id):
    """Get a specific movie"""
    movie = execute_single_query("SELECT * FROM movies WHERE id = %s", (movie_id,))
    if not movie:
        return jsonify({'error': 'Movie not found'}), 404
    return jsonify(movie)

@app.route('/api/movies/<int:movie_id>', methods=['PUT'])
def update_movie(movie_id):
    """Update a movie"""
    data = request.get_json()
    
    # Build update query dynamically
    update_fields = []
    params = []
    
    allowed_fields = ['title', 'release_year', 'genre', 'duration', 'director', 
                     'language', 'description', 'poster_url', 'trailer_url']
    
    for field in allowed_fields:
        if field in data:
            update_fields.append(f"{field} = %s")
            params.append(data[field])
    
    if 'cast' in data:
        update_fields.append('"cast" = %s')
        params.append(json.dumps(data['cast']))
    
    if not update_fields:
        return jsonify({'error': 'No valid fields to update'}), 400
    
    params.append(movie_id)
    query = f"UPDATE movies SET {', '.join(update_fields)} WHERE id = %s RETURNING *"
    
    updated_movie = execute_single_query(query, params)
    
    if updated_movie:
        return jsonify({'message': 'Movie updated successfully', 'movie': updated_movie})
    else:
        return jsonify({'error': 'Movie not found'}), 404

@app.route('/api/movies/<int:movie_id>', methods=['DELETE'])
def delete_movie(movie_id):
    """Delete a movie"""
    # Check if movie exists
    movie = execute_single_query("SELECT title FROM movies WHERE id = %s", (movie_id,))
    if not movie:
        return jsonify({'error': 'Movie not found'}), 404
    
    # Delete movie (reviews will be deleted automatically due to CASCADE)
    success = execute_query("DELETE FROM movies WHERE id = %s", (movie_id,))
    
    if success:
        return jsonify({'message': 'Movie deleted successfully'})
    else:
        return jsonify({'error': 'Failed to delete movie'}), 500

# USER ENDPOINTS
@app.route('/api/users', methods=['GET'])
def get_users():
    """Get all users"""
    users = execute_query("SELECT * FROM users ORDER BY id DESC", fetch=True)
    return jsonify(users or [])

@app.route('/api/users/<int:user_id>/ban', methods=['POST'])
def ban_user(user_id):
    """Ban a user"""
    success = execute_query("UPDATE users SET status = 'banned' WHERE id = %s", (user_id,))
    
    if success:
        return jsonify({'message': 'User banned successfully'})
    else:
        return jsonify({'error': 'User not found'}), 404

@app.route('/api/users/<int:user_id>/unban', methods=['POST'])
def unban_user(user_id):
    """Unban a user"""
    success = execute_query("UPDATE users SET status = 'active' WHERE id = %s", (user_id,))
    
    if success:
        return jsonify({'message': 'User unbanned successfully'})
    else:
        return jsonify({'error': 'User not found'}), 404

# REVIEW ENDPOINTS
@app.route('/api/reviews', methods=['POST'])
def add_review():
    """Add a new review"""
    data = request.get_json()
    
    required_fields = ['movie_id', 'user_id', 'movie_title', 'username', 'rating', 'review_text']
    for field in required_fields:
        if field not in data or not data[field]:
            return jsonify({'error': f'{field} is required'}), 400
    
    try:
        new_review = execute_single_query("""
            INSERT INTO reviews (movie_id, user_id, movie_title, username, rating, review_text, date)
            VALUES (%s, %s, %s, %s, %s, %s, CURRENT_DATE)
            RETURNING id, movie_id, user_id, movie_title, username, rating, review_text, date
        """, (data['movie_id'], data['user_id'], data['movie_title'], data['username'], data['rating'], data['review_text']))
        
        if new_review:
            return jsonify({'message': 'Review added successfully', 'review': new_review}), 201
        else:
            return jsonify({'error': 'Failed to add review'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
@app.route('/api/reviews', methods=['GET'])
def get_reviews():
    """Get all reviews"""
    reviews = execute_query("SELECT * FROM reviews ORDER BY id DESC", fetch=True)
    
    # Convert datetime objects to strings for JSON serialization
    if reviews:
        for review in reviews:
            if 'date' in review and review['date']:
                review['date'] = review['date'].strftime('%B %d, %Y')  # e.g., "June 08, 2025"
    
    return jsonify(reviews or [])

@app.route('/api/reviews/<int:review_id>', methods=['DELETE'])
def delete_review(review_id):
    """Delete a review"""
    # Get review info before deleting
    review = execute_single_query("SELECT movie_id FROM reviews WHERE id = %s", (review_id,))
    if not review:
        return jsonify({'error': 'Review not found'}), 404
    
    # Delete review
    success = execute_query("DELETE FROM reviews WHERE id = %s", (review_id,))
    
    if success:
        # Update movie review count and rating
        execute_query("""
            UPDATE movies SET 
                review_count = (SELECT COUNT(*) FROM reviews WHERE movie_id = %s),
                rating = COALESCE((SELECT AVG(rating) FROM reviews WHERE movie_id = %s), 0)
            WHERE id = %s
        """, (review['movie_id'], review['movie_id'], review['movie_id']))
        
        return jsonify({'message': 'Review deleted successfully'})
    else:
        return jsonify({'error': 'Failed to delete review'}), 500

# GENRE ENDPOINTS
@app.route('/api/genres', methods=['GET'])
def get_genres():
    """Get all genres"""
    # Update movie counts and get genres
    execute_query("""
        UPDATE genres SET movie_count = (
            SELECT COUNT(*) FROM movies WHERE movies.genre = genres.name
        )
    """)
    
    genres = execute_query("SELECT * FROM genres ORDER BY name", fetch=True)
    return jsonify(genres or [])

@app.route('/api/genres', methods=['POST'])
def add_genre():
    """Add a new genre"""
    data = request.get_json()

    if 'name' not in data or not data['name']:
        return jsonify({'error': 'Genre name is required'}), 400

    genre_name = data['name'].lower()

    # Check if genre exists
    existing = execute_single_query("SELECT * FROM genres WHERE name = %s", (genre_name,))
    if existing:
        return jsonify({'error': 'Genre already exists'}), 400

    new_genre = execute_single_query("""
        INSERT INTO genres (name, movie_count) 
        VALUES (%s, 0) 
        RETURNING *
    """, (genre_name,))
    
    if new_genre:
        return jsonify({'message': 'Genre added successfully', 'genre': new_genre}), 200
    else:
        return jsonify({'error': 'Failed to add genre'}), 500


@app.route('/api/genres/<genre_name>', methods=['DELETE'])
def delete_genre(genre_name):
    """Delete a genre"""
    # Check if any movies use this genre
    movie_count = execute_single_query("""
        SELECT COUNT(*) as count FROM movies WHERE genre = %s
    """, (genre_name,))
    
    if movie_count and movie_count['count'] > 0:
        return jsonify({'error': 'Cannot delete genre with existing movies'}), 400
    
    success = execute_query("DELETE FROM genres WHERE name = %s", (genre_name,))
    
    if success:
        return jsonify({'message': 'Genre deleted successfully'})
    else:
        return jsonify({'error': 'Genre not found'}), 404

# SETTINGS ENDPOINTS
@app.route('/api/settings', methods=['GET'])
def get_settings():
    """Get application settings"""
    settings = execute_single_query("SELECT * FROM settings LIMIT 1")
    if not settings:
        # Return default settings if none exist
        settings = {
            'site_name': 'MovieRate',
            'site_description': 'The ultimate destination for movie ratings and reviews',
            'max_rating': 5
        }
    return jsonify(settings)

@app.route('/api/settings', methods=['PUT'])
def update_settings():
    """Update application settings"""
    data = request.get_json()
    
    # Check if settings exist
    existing = execute_single_query("SELECT id FROM settings LIMIT 1")
    
    if existing:
        # Update existing settings
        update_fields = []
        params = []
        
        for key in ['site_name', 'site_description', 'max_rating']:
            if key in data:
                update_fields.append(f"{key} = %s")
                params.append(data[key])
        
        if update_fields:
            query = f"UPDATE settings SET {', '.join(update_fields)} WHERE id = %s RETURNING *"
            params.append(existing['id'])
            updated_settings = execute_single_query(query, params)
            return jsonify({'message': 'Settings updated successfully', 'settings': updated_settings})
    else:
        # Create new settings
        new_settings = execute_single_query("""
            INSERT INTO settings (site_name, site_description, max_rating)
            VALUES (%s, %s, %s) RETURNING *
        """, (
            data.get('site_name', 'MovieRate'),
            data.get('site_description', 'The ultimate destination for movie ratings and reviews'),
            data.get('max_rating', 5)
        ))
        return jsonify({'message': 'Settings created successfully', 'settings': new_settings})

# SEARCH ENDPOINT
@app.route('/api/search', methods=['GET'])
def search():
    """Global search endpoint"""
    query = request.args.get('q', '').lower()
    
    if not query:
        return jsonify({'movies': [], 'users': [], 'reviews': []})
    
    search_term = f'%{query}%'
    
    # Search movies
    movies = execute_query("""
        SELECT * FROM movies 
        WHERE LOWER(title) LIKE %s OR LOWER(genre) LIKE %s OR LOWER(director) LIKE %s
    """, (search_term, search_term, search_term), fetch=True)
    
    # Search users
    users = execute_query("""
        SELECT * FROM users 
        WHERE LOWER(username) LIKE %s OR LOWER(email) LIKE %s
    """, (search_term, search_term), fetch=True)
    
    # Search reviews
    reviews = execute_query("""
        SELECT * FROM reviews 
        WHERE LOWER(review_text) LIKE %s OR LOWER(movie_title) LIKE %s
    """, (search_term, search_term), fetch=True)
    
    return jsonify({
        'movies': movies or [],
        'users': users or [],
        'reviews': reviews or []
    })

# SERVE FRONTEND
@app.route('/')
def login_register():
    return send_file('login_register.html')

@app.route('/admin')
def admin_panel():
    return send_file('index.html')

@app.route('/user')
def user_panel():
    return send_file('user_panel.html')

# USER AUTHENTICATION & PROFILE
@app.route('/api/user/register', methods=['POST'])
def register_user():
    """Register a new user"""
    data = request.get_json()
    
    # Validate required fields
    required_fields = ['username', 'email', 'password']
    for field in required_fields:
        if field not in data or not data[field]:
            return jsonify({'error': f'{field} is required'}), 400
    
    # Check if user already exists
    existing_user = execute_single_query(
        "SELECT id FROM users WHERE username = %s OR email = %s", 
        (data['username'], data['email'])
    )
    
    if existing_user:
        return jsonify({'error': 'Username or email already exists'}), 400
    
    # Create new user
    new_user = execute_single_query("""
        INSERT INTO users (username, email, password, join_date, review_count, status)
        VALUES (%s, %s, %s, CURRENT_DATE, 0, 'active')
        RETURNING id, username, email, join_date, review_count, status
    """, (data['username'], data['email'], data['password']))
    
    if new_user:
        # Add activity
        execute_query("""
            INSERT INTO activities (activity, user_name, movie, date)
            VALUES (%s, %s, %s, %s)
        """, ('User Registration', new_user['username'], '-', 'Just now'))
        
        return jsonify({'message': 'User registered successfully', 'user': new_user}), 201
    else:
        return jsonify({'error': 'Failed to register user'}), 500
    
@app.route('/api/user/login', methods=['POST'])
def login_user():
    """Simple login with admin check"""
    data = request.get_json()
    
    if 'username' not in data or 'password' not in data:
        return jsonify({'error': 'Username and password are required'}), 400
    
    user = execute_single_query(
        "SELECT * FROM users WHERE username = %s AND status = 'active'", 
        (data['username'],)
    )
    
    if user and (user['username'] == 'superadmin' and data['password'] == 'admin123' or 
                 user['username'] != 'superadmin' and user['password'] == data['password']):
        return jsonify({
            'message': 'Login successful', 
            'user': user,
            'isAdmin': user['username'] == 'superadmin'
        })
    else:
        return jsonify({'error': 'Invalid credentials or user banned'}), 401
    
@app.route('/api/user/logout', methods=['POST'])
def logout_user():
    """Clear user session"""
    return jsonify({'message': 'Logged out successfully'})
    

@app.route('/api/user/<username>/profile', methods=['GET'])
def get_user_profile(username):
    """Get user profile with stats"""
    user = execute_single_query("SELECT * FROM users WHERE username = %s", (username,))
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    # Get user's review stats
    review_stats = execute_single_query("""
        SELECT 
            COUNT(*) as total_reviews,
            AVG(rating) as avg_rating
        FROM reviews WHERE username = %s
    """, (username,))
    
    # Get user's recent reviews
    recent_reviews = execute_query("""
        SELECT movie_title, rating, review_text, date
        FROM reviews 
        WHERE username = %s 
        ORDER BY id DESC 
        LIMIT 5
    """, (username,), fetch=True)
    
    profile = {
        **user,
        'total_reviews': review_stats['total_reviews'] if review_stats else 0,
        'avg_rating': round(float(review_stats['avg_rating']) if review_stats and review_stats['avg_rating'] else 0, 1),
        'recent_reviews': recent_reviews or []
    }
    
    return jsonify(profile)

# WATCHLIST ENDPOINTS
@app.route('/api/user/<username>/watchlist', methods=['GET'])
def get_user_watchlist(username):
    """Get user's watchlist"""
    watchlist = execute_query("""
        SELECT m.* FROM movies m
        JOIN watchlist w ON m.id = w.movie_id
        WHERE w.username = %s
        ORDER BY w.added_date DESC
    """, (username,), fetch=True)
    
    return jsonify(watchlist or [])

@app.route('/api/user/<username>/watchlist/<int:movie_id>', methods=['POST'])
def add_to_watchlist(username, movie_id):
    """Add movie to user's watchlist"""
    # Check if movie exists
    movie = execute_single_query("SELECT title FROM movies WHERE id = %s", (movie_id,))
    if not movie:
        return jsonify({'error': 'Movie not found'}), 404
    
    # Check if already in watchlist
    existing = execute_single_query("""
        SELECT id FROM watchlist WHERE username = %s AND movie_id = %s
    """, (username, movie_id))
    
    if existing:
        return jsonify({'error': 'Movie already in watchlist'}), 400
    
    # Add to watchlist
    success = execute_query("""
        INSERT INTO watchlist (username, movie_id, added_date)
        VALUES (%s, %s, CURRENT_DATE)
    """, (username, movie_id))
    
    if success:
        # Add activity
        execute_query("""
            INSERT INTO activities (activity, user_name, movie, date)
            VALUES (%s, %s, %s, %s)
        """, ('Added to Watchlist', username, movie['title'], 'Just now'))
        
        return jsonify({'message': 'Movie added to watchlist'})
    else:
        return jsonify({'error': 'Failed to add to watchlist'}), 500

@app.route('/api/user/<username>/watchlist/<int:movie_id>', methods=['DELETE'])
def remove_from_watchlist(username, movie_id):
    """Remove movie from user's watchlist"""
    success = execute_query("""
        DELETE FROM watchlist WHERE username = %s AND movie_id = %s
    """, (username, movie_id))
    
    if success:
        return jsonify({'message': 'Movie removed from watchlist'})
    else:
        return jsonify({'error': 'Movie not found in watchlist'}), 404

# USER REVIEWS ENDPOINTS
@app.route('/api/user/<username>/reviews', methods=['GET'])
def get_user_reviews(username):
    """Get all reviews by a user"""
    reviews = execute_query("""
        SELECT * FROM reviews 
        WHERE username = %s 
        ORDER BY id DESC
    """, (username,), fetch=True)
    
    return jsonify(reviews or [])

@app.route('/api/user/<username>/reviews', methods=['POST'])
def submit_user_review(username):
    """Submit a new review"""
    data = request.get_json()
    
    # Validate required fields
    required_fields = ['movie_id', 'rating', 'review_text']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'{field} is required'}), 400
    
    # Validate rating
    if not (1 <= int(data['rating']) <= 5):
        return jsonify({'error': 'Rating must be between 1 and 5'}), 400
    
    # Get movie details
    movie = execute_single_query("SELECT title FROM movies WHERE id = %s", (data['movie_id'],))
    if not movie:
        return jsonify({'error': 'Movie not found'}), 404
    
    # Get user ID
    user = execute_single_query("SELECT id FROM users WHERE username = %s", (username,))
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    # Check if user already reviewed this movie
    existing_review = execute_single_query("""
        SELECT id FROM reviews WHERE movie_id = %s AND username = %s
    """, (data['movie_id'], username))
    
    if existing_review:
        return jsonify({'error': 'You have already reviewed this movie'}), 400
    
    # Insert review
    new_review = execute_single_query("""
        INSERT INTO reviews (movie_id, user_id, movie_title, username, rating, review_text, date)
        VALUES (%s, %s, %s, %s, %s, %s, CURRENT_DATE)
        RETURNING *
    """, (data['movie_id'], user['id'], movie['title'], username, data['rating'], data['review_text']))
    
    if new_review:
        # Update movie rating and review count
        execute_query("""
            UPDATE movies SET 
                review_count = (SELECT COUNT(*) FROM reviews WHERE movie_id = %s),
                rating = (SELECT AVG(rating::numeric) FROM reviews WHERE movie_id = %s)
            WHERE id = %s
        """, (data['movie_id'], data['movie_id'], data['movie_id']))
        
        # Update user review count
        execute_query("""
            UPDATE users SET review_count = (
                SELECT COUNT(*) FROM reviews WHERE username = %s
            ) WHERE username = %s
        """, (username, username))
        
        # Add activity
        execute_query("""
            INSERT INTO activities (activity, user_name, movie, date)
            VALUES (%s, %s, %s, %s)
        """, ('New Review', username, movie['title'], 'Just now'))
        
        return jsonify({'message': 'Review submitted successfully', 'review': new_review}), 201
    else:
        return jsonify({'error': 'Failed to submit review'}), 500

@app.route('/api/user/<username>/reviews/<int:review_id>', methods=['PUT'])
def update_user_review(username, review_id):
    """Update user's review"""
    data = request.get_json()
    
    # Check if review belongs to user
    review = execute_single_query("""
        SELECT movie_id FROM reviews WHERE id = %s AND username = %s
    """, (review_id, username))
    
    if not review:
        return jsonify({'error': 'Review not found or unauthorized'}), 404
    
    # Build update query
    update_fields = []
    params = []
    
    if 'rating' in data:
        if not (1 <= int(data['rating']) <= 5):
            return jsonify({'error': 'Rating must be between 1 and 5'}), 400
        update_fields.append("rating = %s")
        params.append(data['rating'])
    
    if 'review_text' in data:
        update_fields.append("review_text = %s")
        params.append(data['review_text'])
    
    if not update_fields:
        return jsonify({'error': 'No valid fields to update'}), 400
    
    params.append(review_id)
    query = f"UPDATE reviews SET {', '.join(update_fields)} WHERE id = %s RETURNING *"
    
    updated_review = execute_single_query(query, params)
    
    if updated_review:
        # Update movie rating
        execute_query("""
            UPDATE movies SET 
                rating = (SELECT AVG(rating::numeric) FROM reviews WHERE movie_id = %s)
            WHERE id = %s
        """, (review['movie_id'], review['movie_id']))
        
        return jsonify({'message': 'Review updated successfully', 'review': updated_review})
    else:
        return jsonify({'error': 'Failed to update review'}), 500

@app.route('/api/user/<username>/reviews/<int:review_id>', methods=['DELETE'])
def delete_user_review(username, review_id):
    """Delete user's review"""
    # Get review info before deleting
    review = execute_single_query("""
        SELECT movie_id FROM reviews WHERE id = %s AND username = %s
    """, (review_id, username))
    
    if not review:
        return jsonify({'error': 'Review not found or unauthorized'}), 404
    
    # Delete review
    success = execute_query("DELETE FROM reviews WHERE id = %s", (review_id,))
    
    if success:
        # Update movie rating and review count
        execute_query("""
            UPDATE movies SET 
                review_count = (SELECT COUNT(*) FROM reviews WHERE movie_id = %s),
                rating = COALESCE((SELECT AVG(rating::numeric) FROM reviews WHERE movie_id = %s), 0)
            WHERE id = %s
        """, (review['movie_id'], review['movie_id'], review['movie_id']))
        
        # Update user review count
        execute_query("""
            UPDATE users SET review_count = (
                SELECT COUNT(*) FROM reviews WHERE username = %s
            ) WHERE username = %s
        """, (username, username))
        
        return jsonify({'message': 'Review deleted successfully'})
    else:
        return jsonify({'error': 'Failed to delete review'}), 500

# MOVIES FOR USER PANEL
@app.route('/api/movies/public', methods=['GET'])
def get_public_movies():
    """Get movies for public/user view with enhanced filtering"""
    search = request.args.get('search', '').lower()
    genre = request.args.get('genre', '')
    year = request.args.get('year', '')
    sort_by = request.args.get('sort', 'newest')  # newest, rating, title
    
    # Base query
    query = "SELECT * FROM movies WHERE 1=1"
    params = []
    
    # Add filters
    if search:
        query += " AND (LOWER(title) LIKE %s OR LOWER(director) LIKE %s OR LOWER(description) LIKE %s)"
        search_param = f'%{search}%'
        params.extend([search_param, search_param, search_param])
    
    if genre:
        query += " AND LOWER(genre) = LOWER(%s)"
        params.append(genre)
    
    if year:
        query += " AND release_year = %s"
        params.append(int(year))
    
    # Add sorting
    if sort_by == 'rating':
        query += " ORDER BY rating DESC, review_count DESC"
    elif sort_by == 'title':
        query += " ORDER BY title ASC"
    else:  # newest
        query += " ORDER BY release_year DESC, id DESC"
    
    movies = execute_query(query, params, fetch=True)
    return jsonify(movies or [])

@app.route('/api/movies/<int:movie_id>/reviews', methods=['GET'])
def get_movie_reviews(movie_id):
    """Get all reviews for a specific movie"""
    reviews = execute_query("""
        SELECT * FROM reviews 
        WHERE movie_id = %s 
        ORDER BY id DESC
    """, (movie_id,), fetch=True)
    
    return jsonify(reviews or [])

# RECOMMENDATIONS
@app.route('/api/user/<username>/recommendations', methods=['GET'])
def get_user_recommendations(username):
    """Get movie recommendations for user based on their reviews"""
    # Get user's favorite genres (from their highest rated reviews)
    user_genres = execute_query("""
        SELECT m.genre, AVG(r.rating) as avg_rating, COUNT(*) as count
        FROM reviews r
        JOIN movies m ON r.movie_id = m.id
        WHERE r.username = %s AND r.rating >= 4
        GROUP BY m.genre
        ORDER BY avg_rating DESC, count DESC
        LIMIT 3
    """, (username,), fetch=True)
    
    if not user_genres:
        # If no reviews, recommend popular movies
        recommendations = execute_query("""
            SELECT * FROM movies 
            ORDER BY rating DESC, review_count DESC 
            LIMIT 10
        """, fetch=True)
    else:
        # Get movies from user's favorite genres that they haven't reviewed
        genre_list = [genre['genre'] for genre in user_genres]
        placeholders = ','.join(['%s'] * len(genre_list))
        
        recommendations = execute_query(f"""
            SELECT * FROM movies 
            WHERE genre IN ({placeholders})
            AND id NOT IN (
                SELECT movie_id FROM reviews WHERE username = %s
            )
            ORDER BY rating DESC, review_count DESC
            LIMIT 10
        """, genre_list + [username], fetch=True)
    
    return jsonify(recommendations or [])

# STATISTICS FOR USER DASHBOARD
@app.route('/api/user/<username>/stats', methods=['GET'])
def get_user_stats(username):
    """Get user statistics"""
    stats = {}
    
    # Total reviews
    result = execute_single_query("""
        SELECT COUNT(*) as count FROM reviews WHERE username = %s
    """, (username,))
    stats['total_reviews'] = result['count'] if result else 0
    
    # Average rating given
    result = execute_single_query("""
        SELECT AVG(rating) as avg_rating FROM reviews WHERE username = %s
    """, (username,))
    stats['avg_rating_given'] = round(float(result['avg_rating']) if result and result['avg_rating'] else 0, 1)
    
    # Watchlist count
    result = execute_single_query("""
        SELECT COUNT(*) as count FROM watchlist WHERE username = %s
    """, (username,))
    stats['watchlist_count'] = result['count'] if result else 0
    
    # Favorite genre
    result = execute_single_query("""
        SELECT m.genre, COUNT(*) as count
        FROM reviews r
        JOIN movies m ON r.movie_id = m.id
        WHERE r.username = %s
        GROUP BY m.genre
        ORDER BY count DESC
        LIMIT 1
    """, (username,))
    stats['favorite_genre'] = result['genre'] if result else 'None'
    
    # Recent activity count
    result = execute_single_query("""
        SELECT COUNT(*) as count FROM activities 
        WHERE user_name = %s AND date LIKE '%ago%'
    """, (username,))
    stats['recent_activities'] = result['count'] if result else 0
    
    return jsonify(stats)

# Serve uploaded files
@app.route('/uploads/<filename>')
def uploaded_file(filename):
    """Serve uploaded files"""
    return send_from_directory('uploads', filename)

# ERROR HANDLERS
@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)