from database import get_db_connection
from psycopg2.extras import RealDictCursor
import json

def create_tables():
    """Drop existing tables and create all required tables"""
    conn = get_db_connection()
    if not conn:
        print("Failed to connect to database")
        return
    
    cursor = conn.cursor()
    
    # Drop all tables in reverse order to avoid foreign key constraints
    drop_tables = [
        "DROP TABLE IF EXISTS watchlist CASCADE;",
        "DROP TABLE IF EXISTS reviews CASCADE;",
        "DROP TABLE IF EXISTS activities CASCADE;",
        "DROP TABLE IF EXISTS genres CASCADE;",
        "DROP TABLE IF EXISTS settings CASCADE;",
        "DROP TABLE IF EXISTS movies CASCADE;",
        "DROP TABLE IF EXISTS users CASCADE;"
    ]
    
    # Create tables
    create_tables = [
        """
        CREATE TABLE IF NOT EXISTS movies (
            id SERIAL PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            release_year INTEGER,
            genre VARCHAR(100),
            duration INTEGER,
            director VARCHAR(255),
            language VARCHAR(100),
            description TEXT,
            "cast" JSONB,
            poster_url TEXT,
            trailer_url TEXT,
            rating DECIMAL(2,1) DEFAULT 0.0,
            review_count INTEGER DEFAULT 0
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            username VARCHAR(100) UNIQUE NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            join_date DATE DEFAULT CURRENT_DATE,
            review_count INTEGER DEFAULT 0,
            status VARCHAR(20) DEFAULT 'active'
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS reviews (
            id SERIAL PRIMARY KEY,
            movie_id INTEGER REFERENCES movies(id) ON DELETE CASCADE,
            user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            movie_title VARCHAR(255),
            username VARCHAR(100),
            rating INTEGER CHECK (rating >= 1 AND rating <= 5),
            review_text TEXT,
            date DATE DEFAULT CURRENT_DATE
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS genres (
            id SERIAL PRIMARY KEY,
            name VARCHAR(100) UNIQUE NOT NULL,
            movie_count INTEGER DEFAULT 0
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS activities (
            id SERIAL PRIMARY KEY,
            activity VARCHAR(255),
            user_name VARCHAR(100),
            movie VARCHAR(255),
            date VARCHAR(50)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS settings (
            id SERIAL PRIMARY KEY,
            site_name VARCHAR(255),
            site_description TEXT,
            max_rating INTEGER DEFAULT 5
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS watchlist (
            id SERIAL PRIMARY KEY,
            username VARCHAR(100) REFERENCES users(username) ON DELETE CASCADE,
            movie_id INTEGER REFERENCES movies(id) ON DELETE CASCADE,
            added_date DATE DEFAULT CURRENT_DATE,
            UNIQUE(username, movie_id)
        )
        """
    ]
    
    try:
        # Drop existing tables
        for drop_query in drop_tables:
            cursor.execute(drop_query)
        print("Existing tables dropped successfully!")
        
        # Create new tables
        for create_query in create_tables:
            cursor.execute(create_query)
        conn.commit()
        print("Tables created successfully!")
        
        # Insert sample data
        insert_sample_data(cursor)
        conn.commit()
        print("Sample data inserted!")
        
    except Exception as e:
        print(f"Error creating tables: {e}")
        conn.rollback()
    finally:
        cursor.close()
        conn.close()

def insert_sample_data(cursor):
    """Insert sample data into tables"""
    # Use RealDictCursor for dictionary-like access
    cursor = cursor.connection.cursor(cursor_factory=RealDictCursor)
    
    # Insert sample movies
    movies_data = [
        ('The Dark Knight', 2008, 'action', 152, 'Christopher Nolan', 'English', 
         'Batman faces the Joker in this epic superhero thriller.',
         json.dumps([{'name': 'Christian Bale', 'role': 'Batman'}, {'name': 'Heath Ledger', 'role': 'Joker'}]),
         'https://example.com/dark-knight.jpg', 'https://youtube.com/watch?v=dark-knight', 4.8, 234),
        ('Inception', 2010, 'sci-fi', 148, 'Christopher Nolan', 'English',
         'A thief enters people\'s dreams to steal secrets.',
         json.dumps([{'name': 'Leonardo DiCaprio', 'role': 'Dom Cobb'}, {'name': 'Marion Cotillard', 'role': 'Mal'}]),
         'https://example.com/inception.jpg', 'https://youtube.com/watch?v=inception', 4.7, 189)
    ]
    
    cursor.execute("DELETE FROM movies")
    cursor.execute("ALTER SEQUENCE movies_id_seq RESTART WITH 1")
    
    for movie in movies_data:
        cursor.execute("""
            INSERT INTO movies (title, release_year, genre, duration, director, language, 
                              description, "cast", poster_url, trailer_url, rating, review_count)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, movie)
    
    # Insert sample users with passwords
    users_data = [
        ('superadmin', 'admin@email.com', 'admin123', '2024-01-15', 0, 'active'),
        ('john_doe', 'john@email.com', 'pass123', '2024-01-15', 23, 'active'),
        ('movie_fan', 'fan@email.com', 'pass123', '2024-02-20', 15, 'active')
    ]
    
    cursor.execute("DELETE FROM users")
    cursor.execute("ALTER SEQUENCE users_id_seq RESTART WITH 1")
    
    for user in users_data:
        cursor.execute("""
            INSERT INTO users (username, email, password, join_date, review_count, status)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, user)
    
    # Insert sample reviews
    cursor.execute("SELECT id, username FROM users")
    users = {row['username']: row['id'] for row in cursor.fetchall()}
    
    reviews_data = [
        (1, users['john_doe'], 'The Dark Knight', 'john_doe', 5, 'Amazing movie with great performances...', '2024-05-15'),
        (2, users['movie_fan'], 'Inception', 'movie_fan', 4, 'Mind-bending plot, excellent direction...', '2024-05-14')
    ]
    
    cursor.execute("DELETE FROM reviews")
    cursor.execute("ALTER SEQUENCE reviews_id_seq RESTART WITH 1")
    
    for review in reviews_data:
        cursor.execute("""
            INSERT INTO reviews (movie_id, user_id, movie_title, username, rating, review_text, date)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, review)
    
    # Insert genres
    genres_data = [
        ('action', 25), ('comedy', 18), ('drama', 32), ('horror', 15),
        ('romance', 22), ('sci-fi', 19), ('thriller', 28), ('animation', 12)
    ]
    
    cursor.execute("DELETE FROM genres")
    
    for genre in genres_data:
        cursor.execute("INSERT INTO genres (name, movie_count) VALUES (%s, %s)", genre)
    
    # Insert activities
    activities_data = [
        ('New Review', 'john_doe', 'The Dark Knight', '2 hours ago'),
        ('Movie Added', 'superadmin', 'Inception', '5 hours ago'),
        ('User Registration', 'movie_fan', '-', '1 day ago')
    ]
    
    cursor.execute("DELETE FROM activities")
    
    for activity in activities_data:
        cursor.execute("""
            INSERT INTO activities (activity, user_name, movie, date)
            VALUES (%s, %s, %s, %s)
        """, activity)
    
    # Insert settings
    cursor.execute("DELETE FROM settings")
    cursor.execute("""
        INSERT INTO settings (site_name, site_description, max_rating)
        VALUES (%s, %s, %s)
    """, ('MovieRate', 'The ultimate destination for movie ratings and reviews', 5))

if __name__ == '__main__':
    create_tables()