
# PostgreSQL Database Settings
DB_CONFIG = {
    'host': 'localhost',
    'database': 'movie_rating_db',
    'user': 'postgres',
    'password': 'Yadnyesh7841',  # Change this to your PostgreSQL password
    'port': 5432
}