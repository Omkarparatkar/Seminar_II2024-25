import psycopg2
from psycopg2.extras import RealDictCursor
from config import DB_CONFIG

def get_db_connection():
    """Create and return database connection"""
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        return conn
    except Exception as e:
        print(f"Database connection error: {e}")
        return None

def execute_query(query, params=None, fetch=False):
    """Execute a database query"""
    conn = get_db_connection()
    if not conn:
        return None
    
    try:
        cursor = conn.cursor(cursor_factory=RealDictCursor)
        cursor.execute(query, params)
        
        if fetch:
            result = cursor.fetchall()
            conn.commit()
            cursor.close()
            conn.close()
            return [dict(row) for row in result]
        else:
            conn.commit()
            cursor.close()
            conn.close()
            return True
    except Exception as e:
        print(f"Query execution error: {e}")
        conn.rollback()
        cursor.close()
        conn.close()
        return None

def execute_single_query(query, params=None):
    """Execute query and return single result"""
    conn = get_db_connection()
    if not conn:
        return None
    
    try:
        cursor = conn.cursor(cursor_factory=RealDictCursor)
        cursor.execute(query, params)
        result = cursor.fetchone()
        conn.commit()
        cursor.close()
        conn.close()
        return dict(result) if result else None
    except Exception as e:
        print(f"Single query error: {e}")
        conn.rollback()
        cursor.close()
        conn.close()
        return None