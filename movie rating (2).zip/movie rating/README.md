# 🎬 MovieRate – Admin Panel for Movie Ratings & Reviews

MovieRate is a web-based admin panel for managing movies, users, reviews, genres, and platform settings. It provides a dashboard overview and user-friendly interface with a modern glassmorphism design.

---

## 📦 Features

- Add, update, and delete movies with cast and details
- Manage users: ban or unban accounts
- Manage reviews and average movie ratings
- Genre management with dynamic movie counts
- Admin settings (site name, description, max rating)
- Dashboard with stats and recent activities
- Fully interactive UI with a modern look

---

## 💻 Technologies Used

### Frontend
- HTML5 + CSS3 (with Glassmorphism Design)
- Vanilla JavaScript

### Backend
- Python 3.10 or later
- Flask (RESTful API)
- Flask-CORS (Cross-origin support)

### Database
- PostgreSQL
- psycopg2-binary (PostgreSQL connector for Python)

---

## 🧰 Prerequisites (Install These First)

Before setting up the project, install the following:

| Tool        | Purpose                          | Download Link                            |
|-------------|----------------------------------|-------------------------------------------|
| Python 3.10+| Backend programming              | https://www.python.org/downloads/         |
| PostgreSQL  | Database system                  | https://www.postgresql.org/download/      |

---

## 📂 Folder Structure

MovieRate/
├── app.py # Flask backend
├── database.py # Database connection & helpers
├── index.html # Frontend UI
├── config.py # PostgreSQL credentials (you create this)
├── README.md # Setup guide
├── requirements.txt # Required Python packages



---

## ⚙️ Step-by-Step Setup Guide 

### ✅ Step 1: Create Project Folder

Create a folder anywhere (e.g., Desktop) and place all project files in it:
- `app.py`, `database.py`, `index.html`, `requirements.txt`

---

### ✅ Step 2: Install Python

1. Download and install Python 3.10+ from [python.org](https://www.python.org/downloads/)
2. During installation, check **"Add Python to PATH"**

---

### ✅ Step 3: Install PostgreSQL

1. Download and install PostgreSQL from [postgresql.org](https://www.postgresql.org/download/)
2. Open **psql** (terminal)
3. write a query in psql terminal: CREATE DATABASE mavie_rating_db;

    
---

### ✅ Step 4: Create `config.py`

In your project folder, create a file named `config.py` and add the following:

```python
DB_CONFIG = {
    'host': 'localhost',
    'database': 'movie_rating_db',
    'user': 'postgres',
    'password': 'YourPassword',  # Change this to your PostgreSQL password
    'port': 5432
}
```

---

### ✅ Step 5: Install Project Dependencies

1. Open VS code and go to project folder.
2. Navigate to terminal.
3. In terminal run the following command: pip install -r requirements.txt

---

### ✅ Step 6: Create Tables and Sample Data

To create tables run below command in terinal:
python setup_db.py


### ✅ Step 7: Run the Flask Server
Start the server using:
python app.py

This will start the backend at:
📍 http://localhost:5000


### ✅ Step 9: Open the Website

click on http://localhost:5000 to go to website. 



# WorkFlow:
1. Login/Register: Here there are two pages one to login and one to register, if you register as user it will take you to user_panel . If you login with username=superadmin and password=admin123 it will take you to admin panel.
2. User Panel: Here you can navigate between movies and add to watchlist and give reviews.
3. Admin Panel: Here you can add new movies , delete , update movies, ban/unban user, view and delete reviews, add and delete genre. 


# Warning:
when adding movies image url first download it locally and select the image from device.

